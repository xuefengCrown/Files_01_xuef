u = (0, 1)
u2 = u
u += (2, 3)
___assertTrue(u is not u2)
