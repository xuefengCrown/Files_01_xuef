if 0 or 0: raise Exception('0 or 0 is true instead of false')
if 1 and 1: pass
else: raise Exception('1 and 1 is false instead of true')
if not 1: raise Exception('not 1 is true instead of false')
