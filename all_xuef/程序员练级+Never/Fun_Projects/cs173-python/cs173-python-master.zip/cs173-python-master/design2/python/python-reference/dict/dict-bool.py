___assertIs(not {}, True)
___assertTrue({1: 2})
___assertIs(bool({}), False)
___assertIs(bool({1: 2}), True)
