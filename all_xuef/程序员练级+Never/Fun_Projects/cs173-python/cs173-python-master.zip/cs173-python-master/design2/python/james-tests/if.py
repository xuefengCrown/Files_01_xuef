if True:
    print("if1-true")
elif True:
    print("if1-elif")
else:
    print("if1-else")

if False:
    print("if2-true")
elif True:
    print("if2-elif")
else:
    print("if2-else")

if False:
    print("if3-true")
elif False:
    print("if3-elif")
else:
    print("if3-else")
