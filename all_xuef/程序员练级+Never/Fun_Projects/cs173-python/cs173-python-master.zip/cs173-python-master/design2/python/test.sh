./run.sh --test $*
