./run.sh --interp
