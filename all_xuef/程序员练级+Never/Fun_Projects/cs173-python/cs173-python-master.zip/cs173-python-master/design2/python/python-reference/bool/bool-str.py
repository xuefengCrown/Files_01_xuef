___assertEqual(str(False), 'False')
___assertEqual(str(True), 'True')
