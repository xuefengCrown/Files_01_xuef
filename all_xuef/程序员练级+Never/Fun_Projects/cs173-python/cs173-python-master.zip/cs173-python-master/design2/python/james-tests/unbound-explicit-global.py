def foo():
    global x
    print(x)

foo()

