___assertIs(callable(len), True)
___assertIs(callable(1), False)
