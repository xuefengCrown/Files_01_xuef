if(not ([] is not [])): raise Exception('list identity')
