___assertTrue(not [])
___assertTrue([42])
