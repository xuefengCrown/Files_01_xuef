___assertEqual(int(False), 0)
___assertIsNot(int(False), False)
___assertEqual(int(True), 1)
___assertIsNot(int(True), True)
