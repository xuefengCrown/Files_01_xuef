___assertEqual(float(False), 0.0)
___assertIsNot(float(False), False)
___assertEqual(float(True), 1.0)
___assertIsNot(float(True), True)
