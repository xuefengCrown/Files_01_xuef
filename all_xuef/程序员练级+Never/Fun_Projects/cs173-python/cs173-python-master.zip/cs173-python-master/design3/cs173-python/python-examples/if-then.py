if 1:
    print(4)

