def memoize(func):
    pass


