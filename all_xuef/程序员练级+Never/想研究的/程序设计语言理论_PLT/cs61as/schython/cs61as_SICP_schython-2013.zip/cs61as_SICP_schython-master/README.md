cs61as_SICP_schython
===========

First off, just want to celebrate this repo, not for any acutal merit, but simply for its personal precedence for me;  this is a Scheme repository,  my first language, first public repo, containing the first projects I have ever really collabrated on with others! :D 

This repository is for cs61as projects and exercises, working through the SICP book (Ableson, Sussman, Sussman).

Should have done this from the start with this class, but I am initializing this repo with my last project for the class, a python interpretor written in scheme -- Scython.
I may go back later and my other projects or favorite programs.  

Please know if browsing through this that I am not intending to step on anyone's toes by posting this material, and if I am doing so unknowingly, please contact me about it.

Aside from the alterations and innovations made by TAs and instructors, this material is straight from the book, "Structure and Interpretation of Computer Programming" which is legitimately free online here: http://www.mitpress.mit.edu/sicp/full-text/book/book.html 
and also available in hardcopy via purchase here: http://www.amazon.com/Structure-Interpretation-Computer-Programs-Engineering/dp/0262510871 .

There is also refference in early stuff which I may retrace later which is from "Simply Scheme," available for free by author here: http://www.eecs.berkeley.edu/~bh/ss-toc2.html .  

I would like to also take this space here to thank and give credit to the awesome people who have facilitated this material for me and many other eager bright-eyed undergrads.  Thank you to:
Andrew Huang
Marion Halim
Jisoo Kim
Sam Lau
The awesome course readers, particularly Reia Cho, who I see from the grade log had the unfortunate task of grading more than the lion's share of my code.
Also, for the Schython Project, and also Adventure World, my partner in crime:
Caro Rodriguez

Finally, thank to you github for being here and awesome, and to anyone who has the remotest desire or pateince to read my code.  Any comments are welcome, particularly on style, code commenting (not quite got this yet), or technical.

Cheers!
-Chris Marie
