'use strict';

module.exports = false;
throw new Error('The elasticsearch npm module is not designed for use in the browser. Please use elasticsearch-browser');
