'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _tooling_log = require('./tooling_log');

Object.defineProperty(exports, 'createToolingLog', {
  enumerable: true,
  get: function get() {
    return _tooling_log.createToolingLog;
  }
});
