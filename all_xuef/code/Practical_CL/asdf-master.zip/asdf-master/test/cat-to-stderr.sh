#!/bin/sh

cat "$@" >&2
